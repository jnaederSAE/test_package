import setuptools

setuptools.setup(
    name='test_package',
    version='1.0.1',
    author='John Naeder',
    description='Testing installation of Package',
    url='https://github.com/jnaederSAE/test_package',
    packages=setuptools.find_packages()
)
